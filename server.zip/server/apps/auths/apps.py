from django.apps import AppConfig


class AuthsConfig(AppConfig):
    name = 'auths'
