from django.apps import AppConfig


class HistoriesConfig(AppConfig):
    name = 'histories'
