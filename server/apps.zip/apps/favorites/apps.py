from django.apps import AppConfig


class FavoritesConfig(AppConfig):
    name = 'favorites'
